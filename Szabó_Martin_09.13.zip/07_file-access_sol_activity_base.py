
with open('devices.txt', 'a') as file:
    while True:
        ujcucc = input("Add meg az eszkoz nevet: ")

        if ujcucc.lower() == 'kilepes':
            print("Kész!")
            break

        file.write(ujcucc + "\n")