"""
Write code to get output below:

What is your first name? First
What is your last name? Last
What is your location? Texas
What is your age? 54
Hi First Last! Your location is Texas and you are 54 years old.
>>>
"""
vezeteknev = input("Add meg a vezeteknevedet")
keresztnev = input("Add meg a keresztnevedet")
varos = input("Add meg hogy hol laksz")
kor = input("Add meg hany eves vagy")

print("Szia",vezeteknev,keresztnev,"te", varos,"-en/ban laksz, es ",kor,"eves vagy")
