nativeVLAN = input("Add meg a nativeVLAN szamat")
dataVLAN = input("Add meg a dataVLAN szamat")

if nativeVLAN == dataVLAN:
     print("a nativeVLAN es a dataVLAN ugyanaz.")
else:
     print("a nativeVLAN es a dataVLAN kulonbozo.")
