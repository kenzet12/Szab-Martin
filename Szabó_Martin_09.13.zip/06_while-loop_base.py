'''
Write Python program :
    get an input for a number to count to
    if input is "q" or "quit", the program exits
    else write numbers from 1 to the number in one line, separated by space and goes back to the input
'''
while True:
    szam = input("Adj meg egy szamot amig elszamoljon a gep (vagy q-t add meg hogy kilepjen a program): ").strip().lower()

    if szam in ('q', 'quit'):
        print("A program akkor kilep.")
        break

    if szam.isdigit():
        szamlalo = int(szam)
        if szamlalo > 0:
            print(" ".join(str(i) for i in range(1, szamlalo + 1)))
        else:
            print("Adj meg a egy pozitiv szamot.")
    else:
        print("Ervenytelen . Adj meg a gy pozitiv szamot vagy 'q-t hogy ' kilepjen a program.")