f = open("devices.txt", "r")
adatok=[]
for adat in f:
    adat = adat.strip()
    adatok.append(adat)
    print(adat.strip())
f.close()

