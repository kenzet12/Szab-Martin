'''
The standard ACL numbers are between 1 and 99 (inclusive)
The extended ACL numbers are between 100 199 (inclusive)
Other ACL numbers are nor standard nor extended.
Input an ACL number and categorize it!
'''
szam = int(input("Adj meg egy szamot 1 es 199 kozott"))

if szam <100:
    print("A szam egy alap ACL szam")
elif szam >199:
    print("A szam amit megadtal nem alap es nem kiterjeszett ACL szam")
else:
    print("A szam egy kiterjesztett ACL szam")
